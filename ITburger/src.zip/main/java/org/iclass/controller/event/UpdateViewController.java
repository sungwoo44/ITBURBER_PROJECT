package org.iclass.controller.event;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.iclass.controller.Controller;
import org.iclass.dao.event.EventDao;
import org.iclass.vo.BG_EVENT;
import org.iclass.vo.BG_USER;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// 요청 매핑 :	mapping.put(new RequestKeyValue("/community/update","GET"), new UpdateViewController() );
public class UpdateViewController implements Controller {
	private static final Logger logger = LoggerFactory.getLogger(UpdateViewController.class);

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//수정 화면으로 데이터 보내기 구현해 보세요.
		//지정된 idx 메인글 가져오기
				String temp = request.getParameter("event_seq");			//메인글 글번호 파라미터로 받기
				int event_seq=0;
				
				//1)현재 접속한 세션에서 사용자 정보를 읽어오기
				HttpSession session = request.getSession();
				BG_USER user = (BG_USER) session.getAttribute("user_id");
				try {
					event_seq = Integer.parseInt(temp);
					EventDao dao = EventDao.getInstance();
					BG_EVENT vo = dao.selectByIdx(event_seq);
				
				//2) idx 글 작성자와 로그인 작성자 비교-일치하지 않으면 예외 발생 (url에서 임의로 idx 를 보낼 수 있기 때문입니다.)
				//   인가(권한) 확인  , 인증 (로그인-사용자확인)	  *인증(Authentication)과 인가(Authorization)*
				if(vo==null || !vo.getUser_id().equals(user.getUser_id())) 
						throw new RuntimeException();		//예외 발생시키기
				
				request.setAttribute("vo", vo);				
					
				/*
				 * //현재페이지를 read.jsp에서 받아 update.jsp로 전달합니다.
				 * logger.info(":::::::UpdateViewController page - {} ::::::::::",request.
				 * getParameter("page"));
				 * request.setAttribute("page",request.getParameter("page") ); //현재페이지 번호 전달 -
				 * 순서4)
				 */
				RequestDispatcher dispatcher = request.getRequestDispatcher("update.jsp");
				dispatcher.forward(request, response);
				}catch (NumberFormatException e) {
					response.sendRedirect(request.getContextPath());
				}
				
				

	}

}
