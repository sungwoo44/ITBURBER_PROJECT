package org.iclass.controller.event;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.iclass.controller.Controller;
import org.iclass.dao.event.EventDao;
import org.iclass.vo.BG_EVENT;

// 요청 매핑 :	mapping.put(new RequestKeyValue("/community/update","POST"), new UpdateController() );  
public class UpdateController implements Controller {

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//수정 내용 저장  구현해 보세요.
		request.setCharacterEncoding("UTF-8");
		int event_seq = Integer.parseInt(request.getParameter("event_seq"));
		String title=request.getParameter("event_title");
		String content=request.getParameter("event_content");
		
		BG_EVENT vo = BG_EVENT.builder()
				.event_seq(event_seq)
				.event_title(title)
				.event_content(content)
				.build();
		
		EventDao dao =	EventDao.getInstance();
		int result = dao.update(vo);
		if(result==1) {
			response.sendRedirect("event?event_seq="+event_seq);   
			//현재페이지 번호 전달 - 순서6)
		}else {
			//메인화면으로 이동
			response.sendRedirect(request.getContextPath());
		}
	}

}
